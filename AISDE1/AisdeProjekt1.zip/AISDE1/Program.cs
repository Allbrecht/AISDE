﻿
using System;

namespace AISDE1
{
    class Program
    {
        static void Main(string[] args)
        {
            QueueTest qt = new QueueTest();
            Simulation simulation = new Simulation();


           
        }        
    }
}

